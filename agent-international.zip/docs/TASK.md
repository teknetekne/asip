Create a minimalist dark-themed landing page (index.html) for ASIP v1.0.

Requirements:
- Hero section with "🌍 ASIP - Workers of the world, compute!"
- Features section (decentralized, reputation system, Moltbook integration)
- Quick start guide
- Footer with GitHub/Moltbook links
- Red/black socialist aesthetics
- Single HTML file, no external dependencies
- Mobile responsive
